export { default as FacebookIcon } from "./facebook-icon";
export { default as GithubIcon } from "./github-icon";
export { default as InstagramIcon } from "./instagram-icon";
export { default as TwitterIcon } from "./twitter-icon";
export { default as YoutubeIcon } from "./youtube-icon";
