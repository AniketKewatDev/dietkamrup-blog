export { default as CategoryHomeIcon } from "./category-home-icon";
export { default as CategoryHealthIcon } from "./category-health-icon";
export { default as CategoryMarketingIcon } from "./category-marketing-icon";
export { default as CategoryScienceIcon } from "./category-science-icon";
export { default as CategoryTechnologyIcon } from "./category-technology-icon";
