import { SharedNotFound } from "@/components/shared";

const NotFound = () => {
  return <SharedNotFound />;
};

export default NotFound;
