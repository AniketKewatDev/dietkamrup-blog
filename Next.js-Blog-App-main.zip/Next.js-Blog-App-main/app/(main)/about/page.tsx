import MainAboutPage from "@/components/main/pages/main-about-page";
import React from "react";

export default function About() {
  return (
    <>
      <MainAboutPage />
    </>
  );
}
