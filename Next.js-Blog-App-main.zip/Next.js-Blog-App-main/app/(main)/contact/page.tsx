import MainContactPage from "@/components/main/pages/main-contact-page";
import React from "react";

export default function ContactPage() {
  return (
    <>
      <MainContactPage />
    </>
  );
}
