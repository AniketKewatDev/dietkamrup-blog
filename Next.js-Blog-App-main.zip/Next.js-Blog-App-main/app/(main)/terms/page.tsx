import MainTermsPage from "@/components/main/pages/main-terms-page";
import React from "react";

export default function Terms() {
  return (
    <>
      <MainTermsPage />
    </>
  );
}
