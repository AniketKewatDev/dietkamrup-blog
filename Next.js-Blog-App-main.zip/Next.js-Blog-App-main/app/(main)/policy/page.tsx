import MainPolicyPage from "@/components/main/pages/main-policy-page";
import React from "react";

export default function Policy() {
  return (
    <>
      <MainPolicyPage />
    </>
  );
}
