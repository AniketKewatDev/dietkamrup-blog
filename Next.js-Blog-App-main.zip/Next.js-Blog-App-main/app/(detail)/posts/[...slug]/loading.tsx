import { DetailPostLoading } from "@/components/detail/post";
import React from "react";

const Loading = () => {
  return (
    <>
      <DetailPostLoading />
    </>
  );
};

export default Loading;
