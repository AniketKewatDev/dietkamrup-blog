import { SharedNotFound } from "@/components/shared";
import React from "react";

const NotFound = () => {
  return <SharedNotFound />;
};

export default NotFound;
