"use client";

import { SharedError } from "@/components/shared";
import React from "react";

const Error = () => {
  return <SharedError />;
};

export default Error;
