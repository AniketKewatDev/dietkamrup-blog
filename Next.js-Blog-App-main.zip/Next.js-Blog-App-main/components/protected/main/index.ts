export { default as ProtectedMain } from "./protected-main";
