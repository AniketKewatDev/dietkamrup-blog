export { default as MainPostItemDesktopLoading } from "./main-post-item-desktop-loading";
export { default as MainPostItemMobileLoading } from "./main-post-item-mobile-loading";
