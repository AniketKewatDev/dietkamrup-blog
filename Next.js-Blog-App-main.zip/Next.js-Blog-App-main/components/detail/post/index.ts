export { default as DetailPostComment } from "./detail-post-comment";
export { default as DetailPostHeading } from "./detail-post-heading";
export { default as DetailPostHeader } from "./detail-post-header";
export { default as DetailPostLoading } from "./detail-post-loading";
export { default as DetailPostFloatingBar } from "./detail-post-floating-bar";
