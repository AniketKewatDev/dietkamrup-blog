export { default as sharedLoginConfig } from "./shared-login-config";
export { default as sharedPagingConfig } from "./shared-paging-config";
export { default as sharedNotFoundConfig } from "./shared-not-found-config";
export { default as sharedEmptyConfig } from "./shared-empty-config";
