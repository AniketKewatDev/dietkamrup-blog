const sharedEmptyConfig = {
  title: "Empty",
  description: "No posts to display",
  error: "Something went wrong",
  tryAgain: "Try again",
  sorry: "Sorry",
};

export default sharedEmptyConfig;
