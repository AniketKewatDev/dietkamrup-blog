const sharedPagingConfig = {
  previous: "Previous",
  next: "Next",
};

export default sharedPagingConfig;
