export { default as detailBookMarkConfig } from "./detail-bookmark-config";
export { default as detailCommentConfig } from "./detail-comment-config";
export { default as detailShareConfig } from "./detail-share-config";
