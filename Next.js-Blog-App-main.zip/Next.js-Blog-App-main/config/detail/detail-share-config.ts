const detailShareConfig = {
  title: "Share",
};

export default detailShareConfig;
