export { default as protectedEditorConfig } from "./protected-editor-config";
export { default as protectedPostConfig } from "./protected-post-config";
export { default as protectedProfileConfig } from "./protected-profile-config";
