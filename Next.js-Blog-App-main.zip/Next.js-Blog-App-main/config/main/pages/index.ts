export { default as mainPageAboutConfig } from "./main-page-about-config";
export { default as mainPageContactConfig } from "./main-page-contact-config";
export { default as mainPagePolicyConfig } from "./main-page-policy-config";
export { default as mainPageTermsConfig } from "./main-page-terms-config";
