const mainPageContactConfig = {
  error: "Error sending message",
  emailSent: "Message sent successfully",
  email: "Email",
  message: "Message",
  send: "Send",
  name: "Name",
};

export default mainPageContactConfig;
