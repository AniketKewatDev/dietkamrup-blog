const mainPostConfig = {
  author: "Author",
};

export default mainPostConfig;
