const mainBannerConfig = {
  title: "Fullstack Blogging App",
  description: "built with Next.js and Supabase.",
  link: "https://github.com/timtbdev/Next.js-Blog-App",
  button: "Github",
};

export default mainBannerConfig;
