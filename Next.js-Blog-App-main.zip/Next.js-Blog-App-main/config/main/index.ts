export { default as mainBannerConfig } from "./main-banner-config";
export { default as sharedEmptyConfig } from "../shared/shared-empty-config";
export { default as mainFooterConfig } from "./main-footer-config";
export { default as mainCategoryConfig } from "./main-category-config";
export { default as mainNewsLetterConfig } from "./main-newsletter-config";
export { default as mainPostConfig } from "./main-post-config";
